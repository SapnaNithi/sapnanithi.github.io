<?php
session_start();
include("dbconnect.php");
extract($_POST);

if($_SESSION['admin']!="atmadmin")
{
header("location:login.php");    
}


$msg="";
$bcode=$_SESSION['bcode'];

$q1=mysql_query("select * from atm_kit where bcode='$bcode'");
$r1=mysql_fetch_array($q1);

if(isset($btn))
{
mysql_query("update atm_kit set mobile='$mobile' where bcode='$bcode'");
?>
<script language="javascript">
alert("Updated...");
window.location.href="add_kit.php";
</script>
<?php
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php include("title.php"); ?></title>
<script language="javascript">
function del()
{
	if(!confirm("Are you sure want to delete?"))
	{
	return false;
	}
	return true;
}
</script>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div class="sd"><!--<a href="index.php">Home</a>-->
    <div align="center">Admin Control </div>
  </div>
  <p>&nbsp;</p>
  <table width="100%" border="0" cellpadding="5" cellspacing="0">

    <tr>
      <th width="15%" valign="top" scope="row"><table width="130" border="0" cellpadding="5">
        <tr>
          <td align="left"><a href="add_kit.php">Kit Mobile No. </a></td>
          </tr>
        <tr>
          <td align="left"><a href="add_user.php">Add User </a></td>
          </tr>
        <tr>
          <td align="left"><a href="view_user.php">View User </a></td>
        </tr>
      </table></th>
      <td width="85%" valign="top"><table width="359" height="126" border="0" align="center">
        <tr>
          <th colspan="2" class="bg1" scope="col">Hardware Mobile Number </th>
        </tr>
        <tr>
          <th align="left" class="bg2" scope="row">Batch Code </th>
          <td align="left" class="bg2"><?php echo $r1['bcode']; ?></td>
        </tr>
        <tr>
          <th align="left" class="bg2" scope="row">Mobile No. </th>
          <td align="left" class="bg2"><input type="text" name="mobile" value="<?php echo $r1['mobile']; ?>" /></td>
        </tr>
        <tr>
          <th align="left" class="bg2" scope="row">&nbsp;</th>
          <td align="left" class="bg2"><input type="submit" name="btn" value="Update" /></td>
        </tr>
      </table>
      <p align="center" class="txt">Mobile No. : <?php echo $r1['mobile']; ?></p></td>
    </tr>
  </table>
  <p align="center" class="txt">&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="center">&nbsp;</p>
  <p align="center" class="sd">
  <a href="home.php">Home</a>
  <a href="details.php">Details</a>
  <a href="logout.php">Logout</a></p>
</form>

</body>
</html>
