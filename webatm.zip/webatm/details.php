<?php
session_start();
include("dbconnect.php");
extract($_POST);
$msg="";
$bocde=$_SESSION['bocde'];
if($_REQUEST['act']=="del")
{
$did=$_REQUEST['did'];
mysql_query("delete from atm_amount where id=$did");
header("location:details.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php include("title.php"); ?></title>
<script language="javascript">
function del()
{
	if(!confirm("Are you sure want to delete?"))
	{
	return false;
	}
	return true;
}
</script>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div class="sd"><!--<a href="index.php">Home</a>-->
    <div align="center">Admin Control </div>
  </div>
  <p align="center" class="txt"><?php include("title.php"); ?></p>
  <?php
  $qry=mysql_query("select * from atm_amount wher bcode='$bcode' order by id desc");
  $num=mysql_num_rows($qry);
  if($num>0)
  {
  ?>
  <table width="650" border="1" align="center" cellpadding="5">
    <tr>
      <th width="57" class="bg1" scope="row">Sno</th>
      <th width="89" class="bg1">User</th>
      <th width="132" class="bg1">Amount</th>
      <th width="200" class="bg1">Date / Time</th>
      <th width="98" class="bg1">Action</th>
    </tr>
	<?php
	$i=0;
	while($row=mysql_fetch_array($qry))
	{
	$i++;
	//$dd=explode(",",$row['voltage']);
	?>
    <tr>
      <td class="bg2" scope="row"><?php echo $i; ?></td>
      <td class="bg2"><?php echo $row['uname']; ?></td>
      <td class="bg2"><?php echo $row['amount']; ?></td>
      <td class="bg2"><?php echo $row['dtime']; ?></td>
      <td class="bg2"><a href="details.php?act=del&did=<?php echo $row['id']; ?>">Delete</a></td>
    </tr>
	
	
	<?php
	}
	?>
  </table>
  <?php
  }
  else
  {
  echo "No Data Found!";
  }
  ?>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="center">&nbsp;</p>
  <p align="center" class="sd">
  <a href="view_user.php">Home</a>
  <a href="details.php">Details</a>
  <a href="logout.php">Logout</a></p>
</form>

</body>
</html>
