<?php
//$connect=mysql_connect("localhost","root","");
//mysql_select_db("webatm",$connect);
$connect=mysql_connect("localhost","projemxh_puser","Project236one");
mysql_select_db("projemxh_db6",$connect);
?>