<?php
session_start();
include("dbconnect.php");
extract($_REQUEST);

if($act=="1")
{
mysql_query("update atm_user set mess='' where bcode='$uname'");
}



$qry=mysql_query("select * from atm_user where bcode='$uname' && mess!=''");
//$qry=mysql_query("select * from atm_user where mess!=''");
$row=mysql_fetch_array($qry);
$mess=$row['mess'];
if($mess!="")
{
echo $mess;
/*echo '<script type="text/javascript">
function redirect()
{

     window.location="amount.php?act=1&uname='.$uname.'";
   
}
   setTimeout(redirect(),15000); 

</script>';*/
}





?>