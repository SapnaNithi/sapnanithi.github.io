<?php
session_start();
include("dbconnect.php");
extract($_POST);
$msg="";
$bcode=$_SESSION['bcode'];

if($_SESSION['admin']!="atmadmin")
{
header("location:login.php");    
}

$q1=mysql_query("select * from atm_kit where bcode='$bcode'");
$r1=mysql_fetch_array($q1);

if(isset($btn))
{
	$mq=mysql_query("select max(id) from atm_user");
		$mr=mysql_fetch_array($mq);
		$id=$mr['max(id)']+1;
		$ins=mysql_query("insert into atm_user(id,name,mobile,email,account,card,deposit,bcode,uname,pass) values($id,'$name','$mobile','$email','$account','$card','10000','$bcode','$uname','$pass')");
		if($ins)
		{
?>
<script language="javascript">
alert("Added...");
window.location.href="add_user.php";
</script>
<?php
		}
		else
		{
	?><script language="javascript">
alert("Username already exist!");
</script>
<?php	
		}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php include("title.php"); ?></title>
<script language="javascript">
function del()
{
	if(!confirm("Are you sure want to delete?"))
	{
	return false;
	}
	return true;
}
</script>
<script language="javascript">
            function validate()
            {
			  
                if (document.form1.name.value == "")
                {
                    alert("Enter the Name");
                    document.form1.name.focus();
                    return false;
                }
				
               
                if (document.form1.mobile.value == "")
                {
                    alert("Enter the Contact No.");
                    document.form1.mobile.focus();
                    return false;
                }
				if (isNaN(document.form1.mobile.value))
                {
                    alert("Invalid Contact No.");
                    document.form1.mobile.select();
                    return false;
                }
				if (document.form1.mobile.value.length != 10)
                {
                    alert("10 digists only allowed!!");
                    document.form1.mobile.select();
                    return false;
                }
				 if (document.form1.email.value == "")
                {
                    alert("Enter the E-mail");
                    document.form1.email.focus();
                    return false;
                }
				/*if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.form1.email.value))  
				  {  
					//return (true)  
				  }  
				  else
				  {
					alert("You have entered an invalid email address!");
					document.form1.email.select();
					return false; 
				  }*/
				if (document.form1.account.value == "")
                {
                    alert("Enter the Account No.");
                    document.form1.account.focus();
                    return false;
                }
				if (document.form1.card.value == "")
                {
                    alert("Enter the Card No.");
                    document.form1.card.focus();
                    return false;
                }
				
                if (document.form1.uname.value == "")
                {
                    alert("Enter the Username");
                    document.form1.uname.focus();
                    return false;
                }
                if (document.form1.pass.value == "")
                {
                    alert("Enter the Password");
                    document.form1.pass.focus();
                    return false;
                }
				
             
                return true;
            }
        </script>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div class="sd"><!--<a href="index.php">Home</a>-->
    <div align="center">Admin Control </div>
  </div>
  <p>&nbsp;</p>
  <table width="100%" border="0" cellpadding="5" cellspacing="0">

    <tr>
      <th width="15%" valign="top" scope="row"><table width="130" border="0" cellpadding="5">
        <tr>
          <td align="left"><a href="add_kit.php">Kit Mobile No. </a></td>
          </tr>
        <tr>
          <td align="left"><a href="add_user.php">Add User </a></td>
          </tr>
        <tr>
          <td align="left"><a href="view_user.php">View User </a></td>
        </tr>
      </table></th>
      <td width="85%" valign="top"><table width="380" height="299" border="0" align="center" cellpadding="5" cellspacing="0">
        <tr>
          <th colspan="2" class="bg1" scope="col">User</th>
        </tr>
        <tr>
          <td align="left" class="bg2">Batch Code </td>
          <td align="left" class="bg2"><?php echo $bcode; ?></td>
        </tr>
        <tr>
          <td width="178" align="left" class="bg2">Name</td>
          <td width="182" align="left" class="bg2"><input type="text" name="name" /></td>
        </tr>
        <tr>
          <td align="left" class="bg2">Mobile No. </td>
          <td align="left" class="bg2"><input type="text" name="mobile" /></td>
        </tr>
        <tr>
          <td align="left" class="bg2">E-mail</td>
          <td align="left" class="bg2"><input type="text" name="email" /></td>
        </tr>
        <tr>
          <td align="left" class="bg2">Account No. </td>
          <td align="left" class="bg2"><input type="text" name="account" /></td>
        </tr>
        <tr>
          <td align="left" class="bg2">Card No. </td>
          <td align="left" class="bg2"><input type="text" name="card" /></td>
        </tr>
        <tr>
          <td align="left" class="bg2">Username</td>
          <td align="left" class="bg2"><input type="text" name="uname" /></td>
        </tr>
        <tr>
          <td align="left" class="bg2">Password</td>
          <td align="left" class="bg2"><input type="password" name="pass" /></td>
        </tr>
        <tr>
          <td colspan="2" align="center" class="bg2"><input name="btn" type="submit" value="Submit" onclick="return validate()" /></td>
        </tr>
        <tr>
          <td colspan="2" align="center" class="bg2"><span class="style1"><?php echo $msg; ?></span></td>
        </tr>
      </table>      
      <p align="center" class="txt">&nbsp;</p></td>
    </tr>
  </table>
  <p align="center" class="txt">&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="center">&nbsp;</p>
  <p align="center" class="sd">
  <a href="home.php">Home</a>
  <a href="details.php">Details</a>
  <a href="logout.php">Logout</a></p>
</form>

</body>
</html>
