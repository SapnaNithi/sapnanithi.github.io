<?php
include("protect.php");
include("dbconnect.php");
extract($_REQUEST);
$msg="";
$bcode=$_SESSION['bcode'];
$q1=mysql_query("select * from atm_amount where uname='$uname' order by id desc");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php include("title.php"); ?></title>

<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div align="center" class="hd"><?php include("title.php"); ?></div>
  <div class="sd"><!--<a href="index.php">Home</a>-->
    <div align="center"><a href="user.php">Home</a> </div>
  </div>
  <h3 align="center">Details</h3>
  <div align="center"><strong>User: <?php echo $uname; ?> </strong></div>
  <table width="897" border="1" align="center">
    <tr>
      <th width="70" scope="col">Sno</th>
      <th width="146" scope="col">Username</th>
      <th width="146" scope="col">Amount</th>
      <th width="334" scope="col">Card Access Holder </th>
      <th width="167" scope="col">Date/Time</th>
    </tr>
	<?php
	$i=0;
	while($r1=mysql_fetch_array($q1))
	{
	$i++;
	?>
    <tr>
      <th scope="row"><?php echo $i; ?></th>
      <td><?php echo $r1['uname']; ?></td>
      <td><?php echo $r1['amount']; ?></td>
      <td><?php echo $r1['name2'].",".$r1['mobile2']; ?></td>
      <td><?php echo $r1['dtime']; ?></td>
    </tr>
	<?php
	}
	?>
  </table>
  <p align="center"><a href="regform.php"></a></p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="center" class="sd"><a href="update.php">Update</a> | <a href="view_details.php">Details</a></p>
</form>
</body>
</html>
