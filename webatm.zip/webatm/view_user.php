<?php
session_start();
include("dbconnect.php");
extract($_POST);
$msg="";
$bcode=$_SESSION['bcode'];

$q1=mysql_query("select * from atm_user where bcode='$bcode'");

if($_SESSION['admin']!="atmadmin")
{
header("location:login.php");    
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php include("title.php"); ?></title>

<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div class="sd"><!--<a href="index.php">Home</a>-->
    <div align="center">Admin Control </div>
  </div>
  <p>&nbsp;</p>
  <table width="100%" border="0" cellpadding="5" cellspacing="0">

    <tr>
      <th width="15%" valign="top" scope="row"><table width="130" border="0" cellpadding="5">
        <tr>
          <td align="left"><a href="add_kit.php">Kit Mobile No. </a></td>
          </tr>
        <tr>
          <td align="left"><a href="add_user.php">Add User </a></td>
          </tr>
        <tr>
          <td align="left"><a href="view_user.php">View User </a></td>
        </tr>
      </table></th>
      <td width="85%" valign="top"><table width="897" border="1" align="center">
        <tr>
          <th width="70" scope="col">Sno</th>
          <th width="146" scope="col">B.Code</th>
          <th width="146" scope="col">Name</th>
          <th width="334" scope="col">Mobile</th>
          <th width="334" scope="col">E-mail</th>
          <th width="334" scope="col">Account</th>
          <th width="334" scope="col">Card No. </th>
          <th width="334" scope="col">Username</th>
          <th width="167" scope="col">Action</th>
        </tr>
        <?php
	$i=0;
	while($r1=mysql_fetch_array($q1))
	{
	$i++;
	?>
        <tr>
          <th scope="row"><?php echo $i; ?></th>
          <td><?php echo $r1['bcode']; ?></td>
          <td><?php echo $r1['name']; ?></td>
          <td><?php echo $r1['mobile']; ?></td>
          <td><?php echo $r1['email']; ?></td>
          <td><?php echo $r1['account']; ?></td>
          <td><?php echo $r1['card']; ?></td>
          <td><?php echo $r1['uname']; ?></td>
          <td><?php echo '<a href="edit.php?id='.$r1['id'].'">Edit</a>'; ?></td>
        </tr>
        <?php
	}
	?>
      </table>
        <p align="center"><a href="regform.php"></a></p>
        <p align="center" class="txt">&nbsp;</p></td>
    </tr>
  </table>
  <p align="center" class="txt">&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="center">&nbsp;</p>
  <p align="center" class="sd">
  <a href="home.php">Home</a>
  <a href="details.php">Details</a>
  <a href="logout.php">Logout</a></p>
</form>

</body>
</html>
