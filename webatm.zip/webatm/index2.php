<?php
session_start();
include("dbconnect.php");
extract($_POST);
$msg="";
$uname=$_REQUEST['uname'];
$q1=mysql_query("select * from atm_user where uname='$uname'");
$r1=mysql_fetch_array($q1);
$card1=substr($r1['card'],0,4);
$card2=substr($r1['card'],4,4);
$card3=substr($r1['card'],8,4);
$card4=substr($r1['card'],12,4);
$stime=$r1['stime'];
$et=date("h:i:s");
$etime=strtotime($et);


$tt=$etime-$stime;
if($tt>300)
{
mysql_query("update atm_user set status=1 where uname='$uname'");
}

$q111=mysql_query("select * from atm_user where uname='$uname'");
$r111=mysql_fetch_array($q111);
if($r111['status']=="1")
{
?>
<script language="javascript">
//window.location.href="page.php";
</script>
<?php
}

if(isset($btn))
{

	if(trim($pass)=="")
	{
	$msg="Enter the PIN Number...";
	}
	else
	{
		$qry=mysql_query("select * from atm_user where pass='$pass' && uname='$uname'");
		$num=mysql_num_rows($qry);
			if($num==1)
			{
			$row=mysql_fetch_array($qry);
			$uname=$row['uname'];
			$_SESSION['uname']=$uname;
			header("location:user.php");
			}
			else
			{
			$msg="Invalid PIN Number!";
			}
	}


}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php include("title.php"); ?></title>

<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div align="center" class="hd"><?php include("title.php"); ?></div>
  <div class="sd"><!--<a href="index.php">Home</a>-->
    <div align="center"><a href="index.php">Home</a></div>
  </div>
  <p>&nbsp;</p>
  <table width="75%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#9AA1B3">
    <tr>
      <th width="63%" scope="col"><img src="images/feature.jpg" width="400" height="400" /></th>
      <th width="37%" valign="top" scope="col"><table width="380" height="299" border="0" align="center" cellpadding="5" cellspacing="0">
        <tr>
          <th colspan="2" class="bg1" scope="col">ATM</th>
          </tr>

        <tr>
          <td width="142" align="left" class="bg2">Name</td>
          <td width="218" align="left" class="bg2"><?php echo $r1['name']; ?></td>
        </tr>
        <tr>
          <td align="left" class="bg2">Savings Account No. </td>
          <td align="left" class="bg2"><?php echo $r1['account']; ?></td>
        </tr>
        <tr>
          <td align="left" class="bg2">Card Number </td>
          <td align="left" class="bg2"><?php echo $card1." ".$card2." ".$card3." ".$card4; ?></td>
        </tr>
        <tr>
          <td align="left" class="bg2">Pin No. </td>
          <td align="left" class="bg2"><input name="pass" type="password" placeholder="Your PIN Number" /></td>
        </tr>
        <tr>
          <td align="left" class="bg2">&nbsp;</td>
          <td align="left" class="bg2"><input name="btn" type="submit" value="Submit" /></td>
        </tr>
        <tr>
          <td colspan="2" align="left" class="bg2"><span class="style1"><?php echo $msg; ?></span></td>
          </tr>
      </table></th>
    </tr>
  </table>
  <p align="center"><a href="regform.php"></a></p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="center" class="sd"><?php include("title.php"); ?></p>
</form>
</body>
</html>
