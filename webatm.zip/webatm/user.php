<?php
include("protect.php");
include("dbconnect.php");
extract($_REQUEST);
$msg="";
$uname=$_SESSION['uname'];
$q1=mysql_query("select * from atm_user where uname='$uname'");
$r1=mysql_fetch_array($q1);
$account=$r1['account'];
$mobile=$r1['mobile'];
$bcode=$r1['bcode'];
$card1=substr($r1['card'],0,4);
$card2=substr($r1['card'],4,4);
$card3=substr($r1['card'],8,4);
$card4=substr($r1['card'],12,4);
if(isset($btn2))
{
	
		$mq=mysql_query("select max(id) from atm_amount");
		$mr=mysql_fetch_array($mq);
		$id=$mr['max(id)']+1;
		
		$mess="9".$amount;
		mysql_query("update atm_user set mess='' where bcode='$bcode'");
		mysql_query("update atm_user set mess='$mess' where bcode='$bcode' && uname='$uname'");
		
		$ins=mysql_query("insert into atm_amount(id,bcode,uname,amount,name2,mobile2) values($id,'$bcode','$uname','$amount','$name2','$mobile2')");
		header("location:user.php?act=ok&amount=$amount&mobile2=$mobile2");
	
}
///////////////////////////////////////
 /* $qry=mysql_query("select * from atm_user where uname='$uname'");
	  $row=mysql_fetch_array($qry);
	  $mobile=$row['mobile'];
	  $message="*".$_REQUEST['amount']."#";
	  echo '<iframe src="http://bulksms.mysmsmantra.com:8080/WebSMS/SMSAPI.jsp?username=AccessContr&password=1848260591&sendername=Access&mobileno=91'.$mobile.',&message='.$message.'" style="display:block"></iframe>';*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php include("title.php"); ?></title>

<link href="style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style3 {
	color: #0066FF;
	font-size: 18px;
}
-->
</style>
<script language="javascript">
/*function contactVal()
{
if (document.form1.amount.value == "")
                {
				document.getElementById("c1").style.display="block";
				document.getElementById("c2").style.display="none";	
				return false;
                }
				else if (isNaN(document.form1.amount.value))
                {
                 document.getElementById("c1").style.display="none";
				document.getElementById("c2").style.display="block";	
				return false;
                }
				else
				{
				document.getElementById("c1").style.display="none";
				document.getElementById("c2").style.display="none";	
				return true;
				}
}
*/

function validate()
{
if (document.form1.amount.value == "")
                {
				document.getElementById("c1").style.display="block";
				document.getElementById("c2").style.display="none";	
				document.getElementById("m1").style.display="none";
				document.getElementById("m2").style.display="none";	
				document.getElementById("m3").style.display="none";
				document.getElementById("n1").style.display="none";
				return false;
                }
				else if (isNaN(document.form1.amount.value))
                {
                 document.getElementById("c1").style.display="none";
				document.getElementById("c2").style.display="block";	
				document.getElementById("m1").style.display="none";
				document.getElementById("m2").style.display="none";	
				document.getElementById("m3").style.display="none";
				document.getElementById("n1").style.display="none";
				return false;
                }
				else if (document.form1.name2.value=="")
                {
                 document.getElementById("c1").style.display="none";
				document.getElementById("c2").style.display="none";	
				document.getElementById("m1").style.display="none";
				document.getElementById("m2").style.display="none";	
				document.getElementById("m3").style.display="none";
				document.getElementById("n1").style.display="block";
				return false;
                }

else if (document.form1.mobile2.value == "")
                {
				document.getElementById("m1").style.display="block";
				document.getElementById("m2").style.display="none";	
				document.getElementById("m3").style.display="none";	
				document.getElementById("c1").style.display="none";
				document.getElementById("c2").style.display="none";	
				document.getElementById("n1").style.display="none";
				return false;
                }
				else if (isNaN(document.form1.mobile2.value))
                {
                 document.getElementById("m1").style.display="none";
				document.getElementById("m2").style.display="block";
				document.getElementById("m3").style.display="none";	
				document.getElementById("c1").style.display="none";
				document.getElementById("c2").style.display="none";	
				document.getElementById("n1").style.display="none";	
				return false;
                }
				else if (document.form1.mobile2.value.length!=10)
                {
                 document.getElementById("m1").style.display="none";
				document.getElementById("m2").style.display="none";
				document.getElementById("m3").style.display="block";	
				document.getElementById("c1").style.display="none";
				document.getElementById("c2").style.display="none";	
				document.getElementById("n1").style.display="none";	
				return false;
                }
				else
				{
				document.getElementById("m1").style.display="none";
				document.getElementById("m2").style.display="none";	
				document.getElementById("m3").style.display="none";	
				document.getElementById("c1").style.display="none";
				document.getElementById("c2").style.display="none";	
				document.getElementById("n1").style.display="none";
				return true;
				}
}
</script>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div align="center" class="hd"><?php include("title.php"); ?></div>
  <div class="sd"><!--<a href="index.php">Home</a>-->
    <div align="center"><a href="index.php">Home</a> </div>
  </div>
  <h2 align="center">&nbsp;</h2>
  <table width="75%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#9AA1B3">
    <tr>
      <th width="63%" scope="col"><img src="images/atm1.jpg" width="430" height="289" /></th>
      <th width="37%" valign="top" scope="col">
	 
	  <table width="380" height="299" border="0" align="center" cellpadding="5" cellspacing="0">
        <tr>
          <th colspan="2" class="bg1" scope="col">ATM</th>
          </tr>
        <tr>
          <td width="160" align="left" class="bg2">Name</td>
          <td width="200" align="left" class="bg2"><?php echo $r1['name']; ?></td>
        </tr>
        <tr>
          <td align="left" class="bg2">Savings Account No. </td>
          <td align="left" class="bg2"><?php echo $r1['account']; ?></td>
        </tr>
        <tr>
          <td align="left" class="bg2">Card Number </td>
          <td align="left" class="bg2"><?php echo $card1." ".$card2." ".$card3." ".$card4; ?></td>
        </tr>

        <tr>
          <td align="left" class="bg2">Enter the Amount </td>
          <td align="left" class="bg2"><input type="text" name="amount" value="<?php echo $amount; ?>" />
            <span id="c1" style="display:none; color:#FF0000">Enter the Amount</span>
			  <span id="c2" style="display:none; color:#FF0000">Invalid Amount!</span>			  </td>
        </tr>
		
        <tr>
          <td colspan="2" align="left" class="bg2">Current Card Access Holder </td>
          </tr>
        <tr>
          <td align="left" class="bg2">Name</td>
          <td align="left" class="bg2"><input type="text" name="name2" />
		  <span id="n1" style="display:none; color:#FF0000">Enter the Name</span></td>
        </tr>
        <tr>
          <td align="left" class="bg2">Mobile No. </td>
          <td align="left" class="bg2"><input type="text" name="mobile2" />
		  <span id="m1" style="display:none; color:#FF0000">Enter the Mobile No.</span>
			  <span id="m2" style="display:none; color:#FF0000">Invalid Mobile No.!</span>
			  <span id="m3" style="display:none; color:#FF0000">Must Enter Mobile No. 10 digits!</span></td>
        </tr>
        <tr>
          <td align="left" class="bg2">&nbsp;</td>
          <td align="left" class="bg2"><input type="submit" name="btn2" value="Submit" onclick="return validate()" /></td>
        </tr>
		
        <tr>
          <td colspan="2" align="left" class="bg2 style3"><?php
		  if($_REQUEST['act']=="ok")
		  {
		  $uu=strtolower($uname);
                   // $uu=$uname;
		 // $message="*".$uu."0";
       /* if($amount=="2000")
                     {
                 $message="*a0";
                   }            
else  if($amount=="1000")
                     {
                 $message="*a0";
                   }
                     else
                       {
                     $message="*a0";
                         }
echo $message;
		  $aq1=mysql_query("select * from atm_kit where bcode='$bcode'");
$ar1=mysql_fetch_array($aq1);
$mobile1=$ar1['mobile'];
*/

		  $message1="Amount Rs.$amount debited from your account";
		  $message2="Amount Rs.$amount received from $account";
		  echo $message2;
		  
	 // echo '<iframe src="http://pay4sms.in/sendsms/?token= b81edee36bcef4ddbaa6ef535f8db03e&credit=2&sender= RandDC&message='.$message.'&number=91'.$mobile1.'" style="display:block"></iframe>';
	  
	  echo '<iframe src="http://pay4sms.in/sendsms/?token= b81edee36bcef4ddbaa6ef535f8db03e&credit=2&sender= RandDC&message='.$message1.'&number=91'.$mobile.'" style="display:block"></iframe>';
	  
	 echo '<iframe src="http://pay4sms.in/sendsms/?token= b81edee36bcef4ddbaa6ef535f8db03e&credit=2&sender= RandDC&message='.$message2.'&number=91'.$mobile2.'" style="display:block"></iframe>';
		  
		  //echo "Success...";
		  
		  echo '<script type="text/javascript">
function redirect()
{

    // window.location="logout.php";
   
}
   //setTimeout(redirect(),15000); 

</script>';
		  }
		  ?></td>
          </tr>
        <tr>
          <td colspan="2" align="left" class="bg2"><span class="style1"><?php echo $msg; ?></span></td>
          </tr>

      </table>
	  </th>
    </tr>
  </table>
  <p align="center"><a href="regform.php"></a></p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="center" class="sd"><a href="update.php">Update</a></p>
</form>
</body>
</html>
