<?php
session_start();
include("dbconnect.php");
extract($_POST);
$msg="";
$user=$_SESSION['user'];



if(isset($btn))
{
$bcode=strtoupper($bcode);
		if(trim($bcode)=="")
		{
		$msg="Enter the Batch Code..";
		}
		else
		{
$_SESSION['bcode']=$bcode;
$q1=mysql_query("select * from atm_kit where bcode='$bcode'");
$n1=mysql_num_rows($q1);
		if($n1==0)
		{
$r1=mysql_fetch_array($q1);

		$mq=mysql_query("select max(id) from atm_kit");
		$mr=mysql_fetch_array($mq);
		$id=$mr['max(id)']+1;
	$ins=mysql_query("insert into atm_kit(id,bcode,mobile) values($id,'$bcode','0')");	
?>
<script language="javascript">
window.location.href="add_kit.php";
</script>
<?php
		}
		else
		{
?>
<script language="javascript">
window.location.href="add_kit.php";
</script>
<?php		
		}
		
		}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php include("title.php"); ?></title>
<script language="javascript">
function del()
{
	if(!confirm("Are you sure want to delete?"))
	{
	return false;
	}
	return true;
}
</script>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div class="sd"><!--<a href="index.php">Home</a>-->
    <div align="center">Admin Control </div>
  </div>
  <p>&nbsp;</p>
  <table width="449" height="126" border="0" align="center">
    <tr>
      <th colspan="2" scope="col">Details</th>
    </tr>
    <tr>
      <th align="left" scope="row">Your Batch Code </th>
      <td align="left"><input type="text" name="bcode" value="<?php echo $r1['bcode']; ?>" /></td>
    </tr>
    <tr>
      <th align="left" scope="row">&nbsp;</th>
      <td align="left"><input type="submit" name="btn" value="Submit" /></td>
    </tr>
  </table>
  <p align="center" class="style1"><?php echo $msg; ?></p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="center">&nbsp;</p>
  <p align="center" class="sd">
  <a href="home.php">Home</a>
 
  <a href="logout.php">Logout</a></p>
</form>

</body>
</html>
