<?php
include("protect.php");
include("dbconnect.php");
extract($_POST);
$msg="";
$uname=$_SESSION['uname'];
$qry=mysql_query("select * from atm_user where uname='$uname'");
$row=mysql_fetch_array($qry);
if(isset($btn))
{
	if(trim($name)=="")
	{
	$msg="Enter the Name...";
	}
	else if(trim($mobile)=="")
	{
	$msg="Enter the Mobile No.";
	}
	else if(strlen($mobile)!=10)
	{
	$msg="Invalid Mobile No!";
	}
	else
	{
		
		$ins=mysql_query("update atm_user set name='$name',mobile='$mobile',email='$email',account='$account',card='$card' where uname='$uname'");
		header("location:user.php");
	}

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php include("title.php"); ?></title>

<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div align="center" class="hd"><?php include("title.php"); ?></div>
  <div class="sd"><!--<a href="index.php">Home</a>-->
    <div align="center"><a href="user.php">Home</a> | <a href="logout.php">Logout</a> </div>
  </div>
  <h2 align="center">Welcome <?php echo $uname; ?></h2>
  <table width="380" height="299" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <th colspan="2" class="bg1" scope="col">Update</th>
    </tr>
    <tr>
      <td align="left" class="bg2">Username</td>
      <td align="left" class="bg2"><?php echo $uname; ?></td>
    </tr>
    <tr>
      <td width="178" align="left" class="bg2">Name</td>
      <td width="182" align="left" class="bg2"><input type="text" name="name" value="<?php echo $row['name']; ?>" /></td>
    </tr>
    <tr>
      <td align="left" class="bg2">Mobile No. </td>
      <td align="left" class="bg2"><input type="text" name="mobile" value="<?php echo $row['mobile']; ?>" /></td>
    </tr>
    <tr>
      <td align="left" class="bg2">E-mail</td>
      <td align="left" class="bg2"><input type="text" name="email" value="<?php echo $row['email']; ?>" /></td>
    </tr>
    <tr>
      <td align="left" class="bg2">Account No. </td>
      <td align="left" class="bg2"><input type="text" name="account" value="<?php echo $row['account']; ?>" /></td>
    </tr>
    <tr>
      <td align="left" class="bg2">Card No. </td>
      <td align="left" class="bg2"><input type="text" name="card" value="<?php echo $row['card']; ?>" /></td>
    </tr>
    <tr>
      <td colspan="2" align="center" class="bg2"><input name="btn" type="submit" value="Submit" /></td>
    </tr>
    <tr>
      <td colspan="2" align="center" class="bg2"><span class="style1"><?php echo $msg; ?></span></td>
    </tr>
  </table>
  <p align="center"><a href="regform.php"></a></p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="center" class="sd"><a href="user.php">Home</a></p>
</form>
</body>
</html>
