<?php
include("dbconnect.php");
extract($_REQUEST);
$stime=date("h:i:s");
$stime=strtotime($stime);
mysql_query("update atm_user set status=0,stime='$stime' where uname='$uname'");

?>